const KEY="theBratsDataV1";
const defaultData={
 tables:Array.from({length:12},(_,i)=>({id:i+1,status:"available",orders:[]})),
 menu:[
  {id:1,name:"Chicken Biryani",cat:"Main Course",price:180},
  {id:2,name:"Paneer Butter Masala",cat:"Main Course",price:170},
  {id:3,name:"Butter Naan",cat:"Breads",price:35},
  {id:4,name:"Tandoori Chicken",cat:"Starters",price:260},
  {id:5,name:"French Fries",cat:"Starters",price:110},
  {id:6,name:"Cold Drink",cat:"Beverage",price:50}
 ],
 bills:[], kot:1
};
let data=JSON.parse(localStorage.getItem(KEY)||"null")||defaultData;
const save=()=>localStorage.setItem(KEY,JSON.stringify(data));
const money=n=>"₹"+Number(n).toFixed(0);
const total=t=>t.orders.reduce((s,o)=>s+o.price*o.qty,0);
const toast=m=>{let x=document.getElementById("toast");x.textContent=m;x.style.display="block";setTimeout(()=>x.style.display="none",1800)};
function go(p){document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.page===p));document.querySelectorAll(".page").forEach(x=>x.classList.toggle("active",x.id===p));if(p==="tables")renderTables();if(p==="kitchen")renderKitchen();if(p==="menu")renderMenu();if(p==="reports")renderReports()}
document.querySelectorAll(".tab").forEach(x=>x.onclick=()=>go(x.dataset.page));
function renderTables(){
 let occ=data.tables.filter(t=>t.status!=="available").length;
 document.getElementById("tableSummary").textContent=`${occ} occupied • ${data.tables.length-occ} available`;
 document.getElementById("tableGrid").innerHTML=data.tables.map(t=>`
 <div class="table ${t.status}">
 <h3>Table ${t.id}</h3><div class="status">${t.status}</div>
 <div class="amount">${money(total(t))}</div>
 <button onclick="openOrder(${t.id})">${t.status==="available"?"Start Order":"View Order"}</button>
 ${t.status!=="available"?`<button onclick="openBill(${t.id})">Bill</button>`:""}
 </div>`).join("");
}
function openOrder(id){
 let t=data.tables.find(x=>x.id===id);
 document.getElementById("modalBody").innerHTML=`<h2>Table ${id}</h2><div id="orderLines"></div><h3 id="orderTotal"></h3>
 <h3>Add Items</h3><div>${data.menu.map(m=>`<button class="item-btn" onclick="addItem(${id},${m.id})"><span>${m.name}<br><small>${m.cat}</small></span><b>${money(m.price)}</b></button>`).join("")}</div>
 <div class="actions"><button class="secondary" onclick="closeModal()">Close</button><button class="primary" onclick="sendKOT(${id})">Send KOT</button><button class="primary" onclick="openBill(${id})">Billing</button></div>`;
 document.getElementById("modal").classList.remove("hidden");refreshOrderModal(id);
}
function refreshOrderModal(id){
 let t=data.tables.find(x=>x.id===id), box=document.getElementById("orderLines");if(!box)return;
 box.innerHTML=t.orders.length?t.orders.map((o,i)=>`<div class="order-item"><span>${o.name} × ${o.qty}</span><span class="qty"><b>${money(o.price*o.qty)}</b><button onclick="changeQty(${id},${i},-1)">−</button><button onclick="changeQty(${id},${i},1)">+</button></span></div>`).join(""):"<p style='color:#6b7280'>No items yet.</p>";
 document.getElementById("orderTotal").textContent="Total: "+money(total(t));
}
function addItem(tid,mid){let t=data.tables.find(x=>x.id===tid),m=data.menu.find(x=>x.id===mid);t.status="occupied";let o=t.orders.find(x=>x.id===mid);if(o)o.qty++;else t.orders.push({id:m.id,name:m.name,price:m.price,qty:1,kitchen:"new"});save();refreshOrderModal(tid);renderTables()}
function changeQty(tid,i,d){let t=data.tables.find(x=>x.id===tid);t.orders[i].qty+=d;if(t.orders[i].qty<=0)t.orders.splice(i,1);if(!t.orders.length)t.status="available";save();refreshOrderModal(tid);renderTables()}
function sendKOT(tid){let t=data.tables.find(x=>x.id===tid);t.orders.forEach(o=>{if(o.kitchen==="new")o.kitchen="preparing"});t.kot=data.kot++;save();toast("KOT sent to kitchen");closeModal();renderTables()}
function renderKitchen(){
 let active=data.tables.filter(t=>t.orders.some(o=>o.kitchen==="preparing"||o.kitchen==="ready"));
 document.getElementById("kitchenGrid").innerHTML=active.length?active.map(t=>`<div class="order-card"><h3>Table ${t.id} • KOT #${t.kot||"-"}</h3>${t.orders.map(o=>`<div class="order-item"><span>${o.name} × ${o.qty}</span><b>${o.kitchen}</b></div>`).join("")}<div class="actions"><button class="primary" onclick="markReady(${t.id})">Mark Ready</button><button class="secondary" onclick="markServed(${t.id})">Served</button></div></div>`).join(""):"<div class='card'><h3>Kitchen clear 🎉</h3><p>No pending orders.</p></div>";
}
function markReady(id){let t=data.tables.find(x=>x.id===id);t.orders.forEach(o=>{if(o.kitchen==="preparing")o.kitchen="ready"});save();renderKitchen();toast("Order marked ready")}
function markServed(id){let t=data.tables.find(x=>x.id===id);t.orders.forEach(o=>o.kitchen="served");save();renderKitchen();toast("Order served")}
function openBill(id){
 let t=data.tables.find(x=>x.id===id), sub=total(t), tax=Math.round(sub*.05), grand=sub+tax;
 document.getElementById("modalBody").innerHTML=`<h2>Bill — Table ${id}</h2>${t.orders.map(o=>`<div class="order-item"><span>${o.name} × ${o.qty}</span><b>${money(o.price*o.qty)}</b></div>`).join("")}<div class="order-item"><span>Subtotal</span><b>${money(sub)}</b></div><div class="order-item"><span>Tax (5%)</span><b>${money(tax)}</b></div><h2>Total ${money(grand)}</h2><div class="form"><select id="pay"><option>Cash</option><option>UPI</option><option>Card</option></select></div><div class="actions"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="closeBill(${id},${grand})">Mark Paid & Close Table</button></div>`;
 document.getElementById("modal").classList.remove("hidden");
}
function closeBill(id,grand){let t=data.tables.find(x=>x.id===id);data.bills.unshift({id:Date.now(),table:id,amount:grand,payment:document.getElementById("pay").value,time:new Date().toLocaleString()});t.status="available";t.orders=[];save();closeModal();renderTables();toast("Bill closed successfully")}
function openItemModal(item=null){
 document.getElementById("modalBody").innerHTML=`<h2>${item?"Edit":"Add"} Menu Item</h2><div class="form"><input id="mn" placeholder="Item name" value="${item?.name||""}"><input id="mc" placeholder="Category" value="${item?.cat||""}"><input id="mp" type="number" placeholder="Price" value="${item?.price||""}"></div><div class="actions"><button class="secondary" onclick="closeModal()">Cancel</button><button class="primary" onclick="saveItem(${item?.id||0})">Save</button></div>`;document.getElementById("modal").classList.remove("hidden");
}
function saveItem(id){let name=document.getElementById("mn").value.trim(),cat=document.getElementById("mc").value.trim()||"Other",price=+document.getElementById("mp").value;if(!name||!price)return toast("Enter item name and price");if(id){let x=data.menu.find(m=>m.id===id);Object.assign(x,{name,cat,price})}else data.menu.push({id:Date.now(),name,cat,price});save();closeModal();renderMenu();toast("Menu saved")}
function renderMenu(){document.getElementById("menuList").innerHTML=data.menu.map(m=>`<div class="menu-row"><span><b>${m.name}</b><br><small>${m.cat}</small></span><span><b>${money(m.price)}</b> <button onclick='openItemModal(${JSON.stringify(m)})'>Edit</button></span></div>`).join("")}
function renderReports(){let sales=data.bills.reduce((s,b)=>s+b.amount,0),orders=data.bills.length,occ=data.tables.filter(t=>t.status!=="available").length;document.getElementById("reportCards").innerHTML=`<div class="stat">Sales<b>${money(sales)}</b></div><div class="stat">Bills<b>${orders}</b></div><div class="stat">Occupied Tables<b>${occ}</b></div><div class="stat">Menu Items<b>${data.menu.length}</b></div>`;document.getElementById("history").innerHTML=data.bills.length?data.bills.slice(0,20).map(b=>`<div class="order-item"><span>Table ${b.table}<br><small>${b.time} • ${b.payment}</small></span><b>${money(b.amount)}</b></div>`).join(""):"<p>No bills yet.</p>"}
function openTableSetup(){document.getElementById("modalBody").innerHTML=`<h2>Add Tables</h2><div class="form"><input id="tableCount" type="number" min="1" value="1"><button class="primary" onclick="addTables()">Add</button></div>`;document.getElementById("modal").classList.remove("hidden")}
function addTables(){let n=Math.max(1,+document.getElementById("tableCount").value||1),start=data.tables.length;for(let i=1;i<=n;i++)data.tables.push({id:start+i,status:"available",orders:[]});save();closeModal();renderTables()}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
let deferred;window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferred=e;document.getElementById("installBtn").classList.remove("hidden")});document.getElementById("installBtn").onclick=async()=>{if(deferred){deferred.prompt();deferred=null}};
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js");
renderTables();
