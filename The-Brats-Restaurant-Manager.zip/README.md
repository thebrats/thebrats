# The Brats Restaurant Manager

Standalone installable PWA for table-wise restaurant management.

## Included
- Table dashboard
- Table-wise orders
- Add items to an existing table
- KOT / kitchen screen
- Billing with 5% tax
- Cash / UPI / Card tracking
- Menu management
- Daily sales and bill history
- Offline local storage
- Installable on Android as a PWA

## Important
This version stores data locally in the browser/device using localStorage. It is a working starter for a single-device restaurant setup. Multi-device synchronization, cloud backup, printer integration, staff login and GST invoice compliance should be added before using it as the restaurant's production system.

## Run
Serve this folder over HTTPS (or localhost) because service workers require a secure context. Then open index.html through the server and use "Install App" / browser "Add to Home screen".
