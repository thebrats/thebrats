const DB_NAME="the-brats-db", DB_VERSION=1;
let db, currentTable=null, cart=[], deferredInstall=null;

const seedMenu=[
 {id:"m1",name:"Classic Burger",category:"Burger",price:149,available:true},
 {id:"m2",name:"French Fries",category:"Snacks",price:99,available:true},
 {id:"m3",name:"Veg Momos",category:"Momos",price:119,available:true},
 {id:"m4",name:"Cold Drink",category:"Beverages",price:60,available:true}
];
const seedOffers=[{id:"o1",name:"Welcome Offer",code:"WELCOME10",type:"percent",value:10,minBill:300,active:true}];

function openDB(){
 return new Promise((resolve,reject)=>{
  const req=indexedDB.open(DB_NAME,DB_VERSION);
  req.onupgradeneeded=e=>{
   const d=e.target.result;
   ["menu","customers","orders","offers"].forEach(s=>{if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:"id"})});
  };
  req.onsuccess=async()=>{db=req.result; await seed(); resolve()};
  req.onerror=()=>reject(req.error);
 });
}
function tx(store,mode="readonly"){return db.transaction(store,mode).objectStore(store)}
function all(store){return new Promise((res,rej)=>{const r=tx(store).getAll();r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
function put(store,obj){return new Promise((res,rej)=>{const r=tx(store,"readwrite").put(obj);r.onsuccess=()=>res(obj);r.onerror=()=>rej(r.error)})}
function remove(store,id){return new Promise((res,rej)=>{const r=tx(store,"readwrite").delete(id);r.onsuccess=()=>res();r.onerror=()=>rej(r.error)})}
async function seed(){
 if((await all("menu")).length===0)for(const x of seedMenu)await put("menu",x);
 if((await all("offers")).length===0)for(const x of seedOffers)await put("offers",x);
}

function money(n){return "₹"+Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2})}
function uid(prefix){return prefix+"-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,6).toUpperCase()}
function showScreen(id){
 document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));
 document.getElementById(id).classList.add("active");
 if(id==="dashboard")refreshDashboard();
 if(id==="tables")renderTables();
 if(id==="menu")renderMenu();
 if(id==="customers")renderCustomers();
 if(id==="offers")renderOffers();
}
async function refreshDashboard(){
 const [c,m,o]=await Promise.all([all("customers"),all("menu"),all("orders")]);
 document.getElementById("customersStat").textContent=c.length;
 document.getElementById("menuStat").textContent=m.length;
 document.getElementById("ordersStat").textContent=o.length;
 document.getElementById("openTablesStat").textContent=(await activeTables()).length;
}
async function activeTables(){return (await all("orders")).filter(o=>o.status==="open").map(o=>o.table).filter((v,i,a)=>a.indexOf(v)===i)}

async function renderTables(){
 const busy=new Set(await activeTables()), el=document.getElementById("tablesGrid");
 el.innerHTML="";
 for(let i=1;i<=12;i++){
  const b=document.createElement("button");b.className="table-card";
  b.innerHTML=`<strong>Table ${i}</strong><div class="status ${busy.has(i)?"busy":""}">${busy.has(i)?"● Occupied":"● Available"}</div>`;
  b.onclick=()=>openTable(i);el.appendChild(b);
 }
}
async function openTable(table){
 currentTable=table;
 const orders=(await all("orders")).filter(o=>o.table===table&&o.status==="open");
 cart=orders.flatMap(o=>o.items||[]).map(x=>({...x}));
 document.getElementById("orderTitle").textContent="Table "+table;
 renderOrderMenu();renderCart();showScreen("order");
}
async function renderOrderMenu(){
 const menu=(await all("menu")).filter(x=>x.available);
 const el=document.getElementById("orderMenu");el.innerHTML="";
 menu.forEach(x=>{
  const b=document.createElement("button");b.className="menu-item";b.innerHTML=`<div><strong>${x.name}</strong><div class="menu-meta">${x.category}</div></div><strong>${money(x.price)}</strong>`;
  b.onclick=()=>{const q=cart.find(i=>i.id===x.id);if(q)q.qty++;else cart.push({id:x.id,name:x.name,price:x.price,qty:1});renderCart()};el.appendChild(b);
 });
}
function renderCart(){
 const el=document.getElementById("cart");el.innerHTML="";
 if(!cart.length){el.innerHTML='<div class="empty">No items yet.</div>';document.getElementById("cartTotal").textContent="₹0";return}
 cart.forEach((x,i)=>{
  const d=document.createElement("div");d.className="cart-line";
  d.innerHTML=`<span>${x.name} × ${x.qty}</span><span>${money(x.price*x.qty)} <button class="ghost" style="padding:3px 8px" onclick="removeCart(${i})">−</button></span>`;
  el.appendChild(d);
 });
 document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
}
function removeCart(i){cart[i].qty--;if(cart[i].qty<=0)cart.splice(i,1);renderCart()}
async function saveCurrentOrder(){
 if(!cart.length)return alert("Add at least one item.");
 const subtotal=cart.reduce((s,x)=>s+x.price*x.qty,0);
 const existing=(await all("orders")).find(o=>o.table===currentTable&&o.status==="open");
 const order=existing||{id:uid("ORD"),table:currentTable,status:"open",createdAt:new Date().toISOString(),payments:[]};
 order.items=cart;order.subtotal=subtotal;order.total=subtotal;order.updatedAt=new Date().toISOString();
 await put("orders",order);
 alert("Order saved offline.");
 showScreen("tables");
}

async function renderMenu(){
 const items=await all("menu"),el=document.getElementById("menuList");el.innerHTML="";
 if(!items.length){el.innerHTML='<div class="empty">No menu items.</div>';return}
 items.forEach(x=>{
  const d=document.createElement("div");d.className="menu-item";
  d.innerHTML=`<div><strong>${x.name}</strong><div class="menu-meta">${x.category} · ${money(x.price)} · ${x.available?"Available":"Unavailable"}</div></div>
  <button class="ghost" onclick='openMenuForm(${JSON.stringify(x).replace(/'/g,"&#39;")})'>Edit</button>`;
  el.appendChild(d);
 });
}
function openMenuForm(item=null){
 openModal(item?"Edit menu item":"Add menu item",`
 <label>Name</label><input id="fName" value="${item?.name||""}" placeholder="e.g. Chicken Burger">
 <label>Category</label><input id="fCat" value="${item?.category||"Other"}" placeholder="Category">
 <label>Price</label><input id="fPrice" inputmode="decimal" value="${item?.price??""}" placeholder="149">
 <label><input id="fAvail" type="checkbox" style="width:auto" ${item?.available!==false?"checked":""}> Available</label>
 <div class="form-actions"><button class="primary" onclick="saveMenu(${item?JSON.stringify(item):"null"})">Save</button><button class="ghost" onclick="closeModal()">Cancel</button></div>`);
}
async function saveMenu(item){
 const obj={id:item?.id||uid("MENU"),name:document.getElementById("fName").value.trim(),category:document.getElementById("fCat").value.trim()||"Other",price:Number(document.getElementById("fPrice").value),available:document.getElementById("fAvail").checked};
 if(!obj.name||obj.price<0)return alert("Enter valid name and price.");
 await put("menu",obj);closeModal();renderMenu();refreshDashboard();
}

async function lookupCustomer(){
 const mobile=document.getElementById("customerSearch").value.replace(/\D/g,"");
 if(mobile.length!==10)return alert("Enter a 10 digit mobile number.");
 let c=(await all("customers")).find(x=>x.mobile===mobile);
 if(!c){
  c={id:uid("CUS"),mobile,customerCode:"BRATS-"+Math.random().toString(36).slice(2,7).toUpperCase(),visits:0,totalSpend:0,createdAt:new Date().toISOString()};
  await put("customers",c);
 }
 const offers=(await all("offers")).filter(x=>x.active);
 document.getElementById("customerResult").innerHTML=`<div class="offer"><strong>Customer found</strong><br>${c.mobile}<br><span class="badge">${c.customerCode}</span><p class="muted">Visits: ${c.visits} · Spend: ${money(c.totalSpend)}</p>${offers.length?offers.map(o=>`<div><strong>🎁 ${o.name}</strong> — ${o.code} — ${o.value}${o.type==="percent"?"%":"₹"} OFF</div>`).join(""):"No active offers"}</div>`;
 renderCustomers();refreshDashboard();
}
async function renderCustomers(){
 const cs=await all("customers"),el=document.getElementById("customerList");el.innerHTML="";
 cs.slice().reverse().forEach(c=>{const d=document.createElement("div");d.className="customer-card";d.innerHTML=`<strong>${c.mobile}</strong> <span class="badge">${c.customerCode}</span><div class="menu-meta">Visits: ${c.visits} · Spend: ${money(c.totalSpend)}</div>`;el.appendChild(d)});
 if(!cs.length)el.innerHTML='<div class="empty">No customers saved yet.</div>';
}
async function renderOffers(){
 const os=await all("offers"),el=document.getElementById("offerList");el.innerHTML="";
 os.forEach(o=>{const d=document.createElement("div");d.className="offer";d.innerHTML=`<strong>${o.name}</strong><div>${o.code}</div><div class="menu-meta">${o.value}${o.type==="percent"?"%":"₹"} OFF · Minimum bill ${money(o.minBill)}</div>`;el.appendChild(d)});
}
function openModal(title,body){document.getElementById("modalTitle").textContent=title;document.getElementById("modalBody").innerHTML=body;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}

window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredInstall=e;document.getElementById("installBtn").classList.remove("hidden")});
document.getElementById("installBtn").onclick=async()=>{if(deferredInstall){deferredInstall.prompt();deferredInstall=null}};
if("serviceWorker" in navigator)window.addEventListener("load",()=>navigator.serviceWorker.register("sw.js"));
openDB().then(()=>refreshDashboard()).catch(e=>alert("Database error: "+e.message));
