# THE BRATS — Part 1

Offline-first restaurant manager PWA.

## Included
- Dashboard
- 12 starter tables
- Local menu database (IndexedDB)
- Add/edit menu items
- Table-wise order cart
- Save open orders locally
- Customer mobile lookup
- Automatic local customer ID
- Local offer list
- PWA service worker

## Run
Serve this folder from a local/static HTTPS-capable web server. A PWA service worker will not normally register from `file://`.

For development, any simple static server works. After loading once online from the server, the app assets are cached and the application data itself stays in IndexedDB on the device.

## Important
Part 1 is the foundation. Payment, bill printing/PDF, full offer rule builder, reports, expenses, PIN lock, backup/restore and APK packaging are planned for later parts.
